This file is an malicious EXE it just causes an bsod But antiviruses call it an trojan
it was formerly called as vblue
Use it for purposes